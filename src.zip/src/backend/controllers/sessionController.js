import Session from "../models/Session";
import Question from "../models/Question";

export const CreateSession = async (req, res) => {
    try {

    }
    catch (error) {
        res.status(500).json({ success: false, message: "Server error!"})
    }
};

export const GetMySessions = async (req, res) => {
    try {

    }
    catch (error) {
        res.status(500).json({ success: false, message: "Server error!"})
    }
};

export const GetSessionById = async (req, res) => {
    try {

    }
    catch (error) {
        res.status(500).json({ success: false, message: "Server error!"})
    }
};

export const DeleteSession = async (req, res) => {
    try {

    }
    catch (error) {
        res.status(500).json({ success: false, message: "Server error!"})
    }
};